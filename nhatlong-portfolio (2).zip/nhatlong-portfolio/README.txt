NHAT LONG - PERSONAL PORTFOLIO

FILES
- index.html   Main page content and structure.
- style.css    Layout, colours, responsive design and animations.
- script.js    Vietnamese/English switch and scroll-reveal effect.
- images/avatar.jpg  Your profile photo used in the About section.

PREVIEW ON YOUR COMPUTER
1. Extract the ZIP file.
2. Open the nhatlong-portfolio folder.
3. Double-click index.html to open it in a browser.
4. Keep index.html, style.css and script.js in the same folder.

PROFILE PHOTO
- The supplied portrait is already installed as images/avatar.jpg.
- To change it later, replace that file with another image named avatar.jpg.
- The image is cropped neatly with CSS; no HTML changes are needed.

PUBLISH WITH GITHUB PAGES
1. Create a GitHub account at https://github.com/ if you do not have one.
2. Sign in, click the + button, then choose New repository.
3. Enter the repository name: nhatlong-portfolio
4. Choose Public, then create the repository.
5. Upload index.html, style.css, script.js, README.txt and the images folder (if it contains files).
6. Open the repository's Settings > Pages.
7. Under Build and deployment, choose Deploy from a branch.
8. Select branch main and folder /(root), then click Save.
9. Wait for GitHub Pages to publish. The website address will be:
   https://YOUR-GITHUB-USERNAME.github.io/nhatlong-portfolio/
   Replace YOUR-GITHUB-USERNAME with your actual GitHub username.

NOTES
- The website is bilingual. Use VI / EN in the top-right corner to switch language.
- The design is responsive for desktop, tablet and mobile screens.
- The GitHub and social-media links are intentionally not fabricated. Add them after those accounts are ready.
- This project uses HTML, CSS and a small JavaScript file for language switching and scroll animations.
